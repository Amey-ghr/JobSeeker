package com.project.JobSeeker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobSeekerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobSeekerApplication.class, args);
	}

}
